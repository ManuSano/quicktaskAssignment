package com.example.quicktask

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
